 <!-- [SERVICES]
 ============================================================================================================================-->
<div class="col-md-3 col-sm-6 O-service">
    <i class="<?php echo get_post_meta(get_the_ID(), 'service_icon', true); ?> themecolor "></i>
        <h4><strong><?php echo get_the_title(); ?></strong></h4>
        <p><?php the_content(); ?></p>
     </div>  
                
 
 
 <!-- [/SERVICES]
 ============================================================================================================================-->
jQuery(document).ready(function ($) {
    // Your code here
    // contact form submission
 $('#contact #eliteContactForm').on('submit' , function(e){

    	e.preventDefault();


 });


});

